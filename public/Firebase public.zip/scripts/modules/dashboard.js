
document.addEventListener("DOMContentLoaded", () => {
  const content = document.getElementById("app-content");
  const loadDashboard = () => {
    fetch("templates/dashboard.html")
      .then(res => res.text())
      .then(html => {
        content.innerHTML = html;
        document.getElementById("inventory-value").textContent = "$4,280.23";
        document.getElementById("monthly-spend").textContent = "$1,152.78";
        document.getElementById("low-stock").textContent = "6";
        document.getElementById("out-of-stock").textContent = "2";
      });
  };

  document.querySelectorAll(".tab-link").forEach(btn => {
    btn.addEventListener("click", () => {
      const module = btn.dataset.module;
      if (module === "dashboard") loadDashboard();
      else content.innerHTML = `<p>${module} module coming soon...</p>`;
    });
  });

  loadDashboard(); // default
});
