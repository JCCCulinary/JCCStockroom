import { StorageController } from "../storage/storageController.js";

export function loadInventoryModule() {
  StorageController.init();

  document.getElementById("addItemBtn")?.addEventListener("click", () => {
    window.location.href = "item-info-page.html";
  });
}