import { StorageController } from "../storage/storageController.js";
import { loadDashboard } from "./dashboard.js";
import { loadInventoryModule } from "./inventory.js";

document.addEventListener("DOMContentLoaded", () => {
  const tabLinks = document.querySelectorAll(".tab-link");
  const content = document.getElementById("app-content");

  tabLinks.forEach(btn => {
    btn.addEventListener("click", async () => {
      const module = btn.dataset.module;
      if (module === "dashboard") {
        const html = await fetch("dashboard.html").then(res => res.text());
        content.innerHTML = html;
        loadDashboard();
      } else if (module === "inventory") {
        const html = await fetch("inventory.html").then(res => res.text());
        content.innerHTML = html;
        loadInventoryModule();
      } else {
        content.innerHTML = "<p>Module not found.</p>";
      }
    });
  });

  // Load default view
  document.querySelector(".tab-link[data-module='dashboard']")?.click();
});